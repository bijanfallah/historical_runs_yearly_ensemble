# Program to plot Create the peudo-observations
# From a nature model run 



library("RNetCDF")

state<-'Taver'
art<-'prior'
exp<-c("norm_prod", "norm_min","norm_T","norm_T_half", "norm_add")
DIR<- '/daten/cady/das_archive_for_paper/batch10/speedy/SST-1854_2010__slab_model/run_length_1800mo'

library("ggplot2")
k<-1
for (i in exp){
        coman <- paste("cdo fldmean -sellevel,0.95 ",DIR,"/assi_run__m24__hLoc500km__InfFac1__stationSet8__obs_op_",
                       i,"/raw_data/assi_",art,"_Emean_grid_sigma_",state,
                      ".nc ",i,".nc",sep ="")
        
        system(coman)
        fid<-open.nc(paste(i,".nc",sep=""))
        dat1<-read.nc(fid)
        name1<- paste("assi_",art,"_",i,"_",state,sep="")
        Var <- as.data.frame(dat1)
        rm(dat1)
        close.nc(fid)
        Var$time<- seq(1861,2010, length.out = length(nature$time))
        name2<- paste("p",k, sep="")
        assign(name2, ggplot(Var, aes(time, t)) + 
                geom_point(col = "black", alpha = .5) + 
                theme_bw() + geom_smooth(method = loess,col = "red", se = F) + 
                labs(title=name1, x=" ", y="Temperature (K)")+
                theme(text=element_text(family = "Times"))+ ylim(285.545, 285.61))
        
     k<- k+1   
}
pdf("Temp_Trends.pdf")
PP<- multiplot(p1,p2, p3, p4, p5, cols = 2, rows = 3) 
dev.off()
