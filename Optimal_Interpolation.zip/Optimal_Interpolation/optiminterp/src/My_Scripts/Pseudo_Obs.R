# Program to plot Create the peudo-observations
# From a nature model run 


setwd('/home/fallah/Documents/DATA_ASSIMILATION/Bijan/CODES/Optimal_Interpolation/optiminterp/src/My_Scripts')
sub_set <- function(data, min_lat, max_lat, min_lon, max_lon) {
        result <- data[ which(data$V1> min_lat & data$V1<max_lat & data$V2> min_lon & data$V2<max_lon ),]
        return(result)
}
        

library("ncdf4")
library("RNetCDF")

exper<-c("MPI", "IPSL","CNRM","MOHC", "ICHEC")
file <- exper[1]

DIR<- '/scratch/users/fallah/Data/'
OBS_COOR = read.table("../Breitenmosser_OBS_coord.txt", sep = ',')
file <- paste(DIR, "tas_", file, "_EU-11.nc", sep = "")

fid <- open.nc(file)
dat<-read.nc(fid)
Temp <- array(dat$tas, dim = c(dim(dat$lat)[1],dim(dat$lon)[2], length(dat$time)))

max_lon <- max(dat$lon)
min_lon <- min(dat$lon)
max_lat <- max(dat$lat)
min_lat <- min(dat$lat)

OBS_RCM <-  sub_set(OBS_COOR, min_lat, max_lat, min_lon, max_lon)


# Var <- as.data.frame(dat1)
rm(dat)
close.nc(fid)
library(maps)
library(mapdata)
map("worldHires", xlim = c(min_lon, max_lon), ylim = c(min_lat, max_lat),col  = 'gray90', fill=TRUE)
points(OBS_RCM$V2,OBS_RCM$V1, pch = 20,  cex = 1.2, col = 'red')
