#!/bin/bash
DIR='/scratch/user/fallah/'
mkdir $DIR/OUT


set -e 
## http://modb.oce.ulg.ac.be/mediawiki/index.php/Optimal_interpolation_Fortran_module_with_Octave_interface#Implementation
gfortran -o example_optiminterp optimal_interpolation.F90  example_optiminterp.F90  /usr/lib/liblapack.so.3 /usr/lib/libblas.so.3
##  Check if it compiles properly:
echo ' ------------------- Compiling the OI code ------------------------: ' 

(./example_optiminterp |  grep -q "0.022206" ) || echo "Error in compilation!!!" 
echo '-------------------------------------------------------------------:'

echo '---  Now checking an example of optimal interpolation ---'  
echo '#'
echo '#'
echo '#'
echo '#'
echo '#'
echo '#'


octave --silent --eval "example_optiminterp_data"





echo '---  Now checking an example of optimal interpolation ---'  
echo '#'
echo '#'
echo '#'
echo '#'
echo '#'
echo '#'
