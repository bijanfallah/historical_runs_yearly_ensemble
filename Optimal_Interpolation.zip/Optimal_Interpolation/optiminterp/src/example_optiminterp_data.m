% This script illustrates a 2D interpolated with user-data

% load the data file
data=load('data.txt');

% the 1st and 2nd column represent the location
x = data(:,1);
y = data(:,2);
% the 3rd column represents the observations to interpolate
obs = data(:,3);

% create a regular mesh from -2 to 2 in x and y direction
% with a grid spacing of 0.1

[xi,yi] = ndgrid(-2:0.1:2,-2:0.1:2);

% number of influential points

m = 30;

% compute the first guess (or background), here we take the 
% mean of all observations
mean_obs = mean(obs);

% remove the mean
f = obs - mean_obs;

% var is the error variance ratio between of the observations and background.
% observations are assumed to be 100 times more accurate (in terms of error variance) than the
% background estimation (here the mean)

var = 0.01 * ones(size(f));

% call optiminterp for 2d case with a correlation length of 1.5 in x and y direction

[fi,vari] = optiminterp2(x,y,d,var,1.5,1.5,m,xi,yi);

% put the mean back
obsi = fi + mean_obs;

dlmwrite ("out.txt", obsi, "delimiter", ",", "newline", "\n")

